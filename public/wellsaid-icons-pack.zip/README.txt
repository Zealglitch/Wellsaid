WellSaid Brand & Extension Icon Pack
====================================
Brand: WellSaid ("Say the hard thing, well.")
Primary Color: Terracotta (#C2410C)
Background Light: #FAF7F2
Card Dark: #1E1B18

FOLDER STRUCTURE & SPECIFICATIONS:
----------------------------------
1. chrome-extension/
   - icon16.png   (16x16)   : Chrome browser toolbar favicons & tab icons
   - icon19.png   (19x19)   : Chrome extension action icon (standard 1x display)
   - icon32.png   (32x32)   : Windows taskbar / Retina 16x16 display
   - icon38.png   (38x38)   : Chrome extension action icon (Retina / high-DPI 2x display)
   - icon48.png   (48x48)   : Chrome Extensions management page (chrome://extensions)
   - icon128.png  (128x128) : Chrome Web Store installation dialog & desktop icon
   - icon256.png  (256x256) : High-resolution displays / app listing
   - icon512.png  (512x512) : Master store icon & Google Play / PWA splash

2. chrome-webstore/
   - store_icon_128x128.png    (128x128)  : Official Chrome Web Store listing icon
   - small_promo_440x280.png   (440x280)  : Small Promo Tile (Chrome Web Store recommendation cards)
   - large_promo_920x680.png   (920x680)  : Large Promo Tile (Chrome Web Store category headers)
   - marquee_1400x560.png      (1400x560) : Marquee Promotional Banner (Chrome Web Store top carousel feature)

3. transparent-background/
   - icon16_transparent.png    (16x16)
   - icon32_transparent.png    (32x32)
   - icon48_transparent.png    (48x48)
   - icon128_transparent.png   (128x128)
   - icon512_transparent.png   (512x512)

4. web-and-pwa/
   - favicon-16x16.png         (16x16)    : Web browser tab favicon
   - favicon-32x32.png         (32x32)    : Retina web browser tab favicon
   - apple-touch-icon.png      (180x180)  : iOS Home Screen Bookmark
   - pwa-192x192.png           (192x192)  : Android homescreen / PWA manifest
   - pwa-512x512.png           (512x512)  : PWA splash screen & full screen install

5. vector-svg/
   - wellsaid-icon.svg         : Infinite resolution SVG master with terracotta squircle
   - wellsaid-icon-transparent.svg : Infinite resolution SVG master with transparent background
